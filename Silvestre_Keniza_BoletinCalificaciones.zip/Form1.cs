using System;
using System.Windows.Forms;

namespace Actividad__Boletin_Calificaciones_Keniza
{
    public partial class Form1 : Form
    {
        const double NotaAprobada = 70;
        const double NotaRecuperacion = 60;
        const int CantPeriodos = 4;

        int cantidadAsignaturas = 0;
        int cantidadAprobadas = 0;
        int cantidadRecuperacion = 0;
        int cantidadReprobadas = 0;

        double acumuladorPromedios = 0;

        public Form1()
        {
            InitializeComponent();

            cmbAsignatura.Items.Add("Matemática");
            cmbAsignatura.Items.Add("Lengua Española");
            cmbAsignatura.Items.Add("Ciencias Naturales");
            cmbAsignatura.Items.Add("Inglés");
            cmbAsignatura.Items.Add("Informática");

            cmbAsignatura.DropDownStyle = ComboBoxStyle.DropDownList;

            rdbMatutina.Checked = true;
            chkAsistencia.Checked = true;

            btnResumen.Click += btnResumen_Click;
            btnLimpiar.Click += btnLimpiar_Click;
            btnSalir.Click += btnSalir_Click;
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            double p1, p2, p3, p4;

            if (txtEstudiante.Text.Trim() == "")
            {
                MessageBox.Show("Escribe el nombre del estudiante.");
                txtEstudiante.Focus();
                return;
            }

            if (!rdbMatutina.Checked && !rdbVespertina.Checked)
            {
                MessageBox.Show("Selecciona la tanda.");
                return;
            }

            if (cmbAsignatura.SelectedIndex == -1)
            {
                MessageBox.Show("Selecciona una asignatura.");
                return;
            }

            if (!double.TryParse(txtP1.Text, out p1) ||
                !double.TryParse(txtP2.Text, out p2) ||
                !double.TryParse(txtP3.Text, out p3) ||
                !double.TryParse(txtP4.Text, out p4))
            {
                MessageBox.Show("Completa las cuatro calificaciones.");
                return;
            }

            if (p1 < 0 || p1 > 100 ||
                p2 < 0 || p2 > 100 ||
                p3 < 0 || p3 > 100 ||
                p4 < 0 || p4 > 100)
            {
                MessageBox.Show("Las notas deben estar entre 0 y 100.");
                return;
            }

            double promedio = (p1 + p2 + p3 + p4) / CantPeriodos;

            string situacion;

            if (!chkAsistencia.Checked)
            {
                situacion = "Reprobada";
            }
            else if (promedio >= NotaAprobada)
            {
                situacion = "Aprobada";
            }
            else if (promedio >= NotaRecuperacion)
            {
                situacion = "En recuperación";
            }
            else
            {
                situacion = "Reprobada";
            }

            lstBoletin.Items.Add(
                cmbAsignatura.Text + " - " +
                promedio.ToString("F2") + " - " +
                situacion
            );

            cantidadAsignaturas++;
            acumuladorPromedios += promedio;

            if (situacion == "Aprobada")
            {
                cantidadAprobadas++;
            }
            else if (situacion == "En recuperación")
            {
                cantidadRecuperacion++;
            }
            else
            {
                cantidadReprobadas++;
            }

            ActualizarContadores();

            txtP1.Clear();
            txtP2.Clear();
            txtP3.Clear();
            txtP4.Clear();

            cmbAsignatura.SelectedIndex = -1;
            chkAsistencia.Checked = true;

            MessageBox.Show("Asignatura registrada correctamente.");
        }

        private void btnResumen_Click(object sender, EventArgs e)
        {
            if (cantidadAsignaturas == 0)
            {
                MessageBox.Show("Registra al menos una asignatura.");
                return;
            }

            double promedioGeneral = acumuladorPromedios / cantidadAsignaturas;

            lblPromedioGeneral.Text =
                "Promedio general: " + promedioGeneral.ToString("F2");

            if (cantidadReprobadas > 0)
            {
                lblSituacion.Text = "Situación: Tiene asignaturas reprobadas";
            }
            else if (cantidadRecuperacion > 0)
            {
                lblSituacion.Text = "Situación: Tiene asignaturas en recuperación";
            }
            else
            {
                lblSituacion.Text = "Situación: Todas las asignaturas aprobadas";
            }

            ActualizarContadores();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtEstudiante.Clear();

            rdbMatutina.Checked = true;
            rdbVespertina.Checked = false;

            cmbAsignatura.SelectedIndex = -1;

            txtP1.Clear();
            txtP2.Clear();
            txtP3.Clear();
            txtP4.Clear();

            chkAsistencia.Checked = true;

            lstBoletin.Items.Clear();

            cantidadAsignaturas = 0;
            cantidadAprobadas = 0;
            cantidadRecuperacion = 0;
            cantidadReprobadas = 0;

            acumuladorPromedios = 0;

            lblPromedioGeneral.Text = "Promedio general:";
            lblSituacion.Text = "Situación:";

            ActualizarContadores();

            txtEstudiante.Focus();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ActualizarContadores()
        {
            lblAprobadas.Text = "Aprobadas: " + cantidadAprobadas;
            lblRecuperacion.Text = "En recuperación: " + cantidadRecuperacion;
            lblReprobadas.Text = "Reprobadas: " + cantidadReprobadas;
        }

        private void rdbVespertina_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void lblP1_Click(object sender, EventArgs e)
        {
        }

        private void lblP3_Click(object sender, EventArgs e)
        {
        }

        private void txtP4_TextChanged(object sender, EventArgs e)
        {
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void lblRecuperacion_Click(object sender, EventArgs e)
        {
        }
    }
}