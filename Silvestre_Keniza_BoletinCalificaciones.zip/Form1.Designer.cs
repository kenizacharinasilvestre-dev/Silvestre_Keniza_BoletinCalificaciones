﻿namespace Actividad__Boletin_Calificaciones_Keniza
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblBoletinCalificaciones = new Label();
            grpEstudiante = new GroupBox();
            label1 = new Label();
            txtEstudiante = new TextBox();
            lblTanda = new Label();
            rdbMatutina = new RadioButton();
            rdbVespertina = new RadioButton();
            grpRegistroAsignatura = new GroupBox();
            lblAsignatura = new Label();
            cmbAsignatura = new ComboBox();
            lblCalificaciones = new Label();
            lblP1 = new Label();
            txtP1 = new TextBox();
            lblP2 = new Label();
            txtP2 = new TextBox();
            lblP3 = new Label();
            txtP3 = new TextBox();
            lblP4 = new Label();
            txtP4 = new TextBox();
            chkAsistencia = new CheckBox();
            btnRegistrar = new Button();
            btnResumen = new Button();
            btnLimpiar = new Button();
            grpBoletin = new GroupBox();
            lstBoletin = new ListBox();
            grpResumen = new GroupBox();
            lblPromedioGeneral = new Label();
            lblAprobadas = new Label();
            lblRecuperacion = new Label();
            lblReprobadas = new Label();
            lblSituacion = new Label();
            btnSalir = new Button();
            grpEstudiante.SuspendLayout();
            grpRegistroAsignatura.SuspendLayout();
            grpBoletin.SuspendLayout();
            grpResumen.SuspendLayout();
            SuspendLayout();
            // 
            // lblBoletinCalificaciones
            // 
            lblBoletinCalificaciones.AutoSize = true;
            lblBoletinCalificaciones.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblBoletinCalificaciones.Location = new Point(12, 9);
            lblBoletinCalificaciones.Name = "lblBoletinCalificaciones";
            lblBoletinCalificaciones.Size = new Size(245, 28);
            lblBoletinCalificaciones.TabIndex = 0;
            lblBoletinCalificaciones.Text = "Boletin de Calificaciones";
            // 
            // grpEstudiante
            // 
            grpEstudiante.Controls.Add(rdbVespertina);
            grpEstudiante.Controls.Add(rdbMatutina);
            grpEstudiante.Controls.Add(lblTanda);
            grpEstudiante.Controls.Add(txtEstudiante);
            grpEstudiante.Controls.Add(label1);
            grpEstudiante.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            grpEstudiante.Location = new Point(12, 47);
            grpEstudiante.Name = "grpEstudiante";
            grpEstudiante.Size = new Size(421, 188);
            grpEstudiante.TabIndex = 1;
            grpEstudiante.TabStop = false;
            grpEstudiante.Text = "Datos del Estudiante";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(6, 37);
            label1.Name = "label1";
            label1.Size = new Size(67, 20);
            label1.TabIndex = 0;
            label1.Text = "Nombre:";
            // 
            // txtEstudiante
            // 
            txtEstudiante.Location = new Point(79, 37);
            txtEstudiante.Name = "txtEstudiante";
            txtEstudiante.Size = new Size(263, 27);
            txtEstudiante.TabIndex = 1;
            // 
            // lblTanda
            // 
            lblTanda.AutoSize = true;
            lblTanda.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTanda.Location = new Point(6, 89);
            lblTanda.Name = "lblTanda";
            lblTanda.Size = new Size(51, 20);
            lblTanda.TabIndex = 2;
            lblTanda.Text = "Tanda:";
            // 
            // rdbMatutina
            // 
            rdbMatutina.AutoSize = true;
            rdbMatutina.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            rdbMatutina.Location = new Point(79, 89);
            rdbMatutina.Name = "rdbMatutina";
            rdbMatutina.Size = new Size(89, 24);
            rdbMatutina.TabIndex = 3;
            rdbMatutina.TabStop = true;
            rdbMatutina.Text = "Matutina";
            rdbMatutina.UseVisualStyleBackColor = true;
            // 
            // rdbVespertina
            // 
            rdbVespertina.AutoSize = true;
            rdbVespertina.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            rdbVespertina.Location = new Point(211, 89);
            rdbVespertina.Name = "rdbVespertina";
            rdbVespertina.Size = new Size(99, 24);
            rdbVespertina.TabIndex = 4;
            rdbVespertina.TabStop = true;
            rdbVespertina.Text = "Vespertina";
            rdbVespertina.UseVisualStyleBackColor = true;
            rdbVespertina.CheckedChanged += rdbVespertina_CheckedChanged;
            // 
            // grpRegistroAsignatura
            // 
            grpRegistroAsignatura.Controls.Add(btnRegistrar);
            grpRegistroAsignatura.Controls.Add(chkAsistencia);
            grpRegistroAsignatura.Controls.Add(txtP4);
            grpRegistroAsignatura.Controls.Add(lblP4);
            grpRegistroAsignatura.Controls.Add(txtP3);
            grpRegistroAsignatura.Controls.Add(lblP3);
            grpRegistroAsignatura.Controls.Add(txtP2);
            grpRegistroAsignatura.Controls.Add(lblP2);
            grpRegistroAsignatura.Controls.Add(txtP1);
            grpRegistroAsignatura.Controls.Add(lblP1);
            grpRegistroAsignatura.Controls.Add(lblCalificaciones);
            grpRegistroAsignatura.Controls.Add(cmbAsignatura);
            grpRegistroAsignatura.Controls.Add(lblAsignatura);
            grpRegistroAsignatura.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            grpRegistroAsignatura.Location = new Point(12, 258);
            grpRegistroAsignatura.Name = "grpRegistroAsignatura";
            grpRegistroAsignatura.Size = new Size(421, 293);
            grpRegistroAsignatura.TabIndex = 2;
            grpRegistroAsignatura.TabStop = false;
            grpRegistroAsignatura.Text = "Registro de Asignatura";
            // 
            // lblAsignatura
            // 
            lblAsignatura.AutoSize = true;
            lblAsignatura.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAsignatura.Location = new Point(11, 35);
            lblAsignatura.Name = "lblAsignatura";
            lblAsignatura.Size = new Size(83, 20);
            lblAsignatura.TabIndex = 0;
            lblAsignatura.Text = "Asignatura:";
            // 
            // cmbAsignatura
            // 
            cmbAsignatura.FormattingEnabled = true;
            cmbAsignatura.Location = new Point(100, 32);
            cmbAsignatura.Name = "cmbAsignatura";
            cmbAsignatura.Size = new Size(242, 28);
            cmbAsignatura.TabIndex = 1;
            // 
            // lblCalificaciones
            // 
            lblCalificaciones.AutoSize = true;
            lblCalificaciones.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCalificaciones.Location = new Point(11, 85);
            lblCalificaciones.Name = "lblCalificaciones";
            lblCalificaciones.Size = new Size(249, 20);
            lblCalificaciones.TabIndex = 2;
            lblCalificaciones.Text = "Calificaciones por periodo (0 a 100):";
            // 
            // lblP1
            // 
            lblP1.AutoSize = true;
            lblP1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblP1.Location = new Point(32, 120);
            lblP1.Name = "lblP1";
            lblP1.Size = new Size(25, 20);
            lblP1.TabIndex = 3;
            lblP1.Text = "P1";
            lblP1.Click += lblP1_Click;
            // 
            // txtP1
            // 
            txtP1.Location = new Point(11, 142);
            txtP1.Name = "txtP1";
            txtP1.Size = new Size(71, 27);
            txtP1.TabIndex = 4;
            // 
            // lblP2
            // 
            lblP2.AutoSize = true;
            lblP2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblP2.Location = new Point(123, 120);
            lblP2.Name = "lblP2";
            lblP2.Size = new Size(25, 20);
            lblP2.TabIndex = 5;
            lblP2.Text = "P2";
            // 
            // txtP2
            // 
            txtP2.Location = new Point(100, 143);
            txtP2.Name = "txtP2";
            txtP2.Size = new Size(68, 27);
            txtP2.TabIndex = 6;
            // 
            // lblP3
            // 
            lblP3.AutoSize = true;
            lblP3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblP3.Location = new Point(200, 120);
            lblP3.Name = "lblP3";
            lblP3.Size = new Size(25, 20);
            lblP3.TabIndex = 7;
            lblP3.Text = "P3";
            lblP3.Click += lblP3_Click;
            // 
            // txtP3
            // 
            txtP3.Location = new Point(185, 143);
            txtP3.Name = "txtP3";
            txtP3.Size = new Size(75, 27);
            txtP3.TabIndex = 8;
            // 
            // lblP4
            // 
            lblP4.AutoSize = true;
            lblP4.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblP4.Location = new Point(285, 120);
            lblP4.Name = "lblP4";
            lblP4.Size = new Size(25, 20);
            lblP4.TabIndex = 9;
            lblP4.Text = "P4";
            // 
            // txtP4
            // 
            txtP4.Location = new Point(266, 143);
            txtP4.Name = "txtP4";
            txtP4.Size = new Size(75, 27);
            txtP4.TabIndex = 10;
            txtP4.TextChanged += txtP4_TextChanged;
            // 
            // chkAsistencia
            // 
            chkAsistencia.AutoSize = true;
            chkAsistencia.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            chkAsistencia.Location = new Point(6, 196);
            chkAsistencia.Name = "chkAsistencia";
            chkAsistencia.Size = new Size(262, 24);
            chkAsistencia.TabIndex = 11;
            chkAsistencia.Text = "Cumple la asistencia minima (80%)";
            chkAsistencia.UseVisualStyleBackColor = true;
            // 
            // btnRegistrar
            // 
            btnRegistrar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRegistrar.Location = new Point(100, 246);
            btnRegistrar.Name = "btnRegistrar";
            btnRegistrar.Size = new Size(210, 36);
            btnRegistrar.TabIndex = 12;
            btnRegistrar.Text = "Registrar asignatura";
            btnRegistrar.UseVisualStyleBackColor = true;
            btnRegistrar.Click += btnRegistrar_Click;
            // 
            // btnResumen
            // 
            btnResumen.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnResumen.Location = new Point(29, 589);
            btnResumen.Name = "btnResumen";
            btnResumen.Size = new Size(243, 52);
            btnResumen.TabIndex = 3;
            btnResumen.Text = "Mostrar resumen";
            btnResumen.UseVisualStyleBackColor = true;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLimpiar.Location = new Point(342, 589);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(243, 52);
            btnLimpiar.TabIndex = 4;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            // 
            // grpBoletin
            // 
            grpBoletin.Controls.Add(lstBoletin);
            grpBoletin.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            grpBoletin.Location = new Point(485, 47);
            grpBoletin.Name = "grpBoletin";
            grpBoletin.Size = new Size(401, 217);
            grpBoletin.TabIndex = 5;
            grpBoletin.TabStop = false;
            grpBoletin.Text = "Boletin del Estudiante";
            // 
            // lstBoletin
            // 
            lstBoletin.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lstBoletin.FormattingEnabled = true;
            lstBoletin.Location = new Point(18, 33);
            lstBoletin.Name = "lstBoletin";
            lstBoletin.Size = new Size(363, 144);
            lstBoletin.TabIndex = 0;
            lstBoletin.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // grpResumen
            // 
            grpResumen.Controls.Add(lblSituacion);
            grpResumen.Controls.Add(lblReprobadas);
            grpResumen.Controls.Add(lblRecuperacion);
            grpResumen.Controls.Add(lblAprobadas);
            grpResumen.Controls.Add(lblPromedioGeneral);
            grpResumen.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            grpResumen.Location = new Point(485, 282);
            grpResumen.Name = "grpResumen";
            grpResumen.Size = new Size(401, 258);
            grpResumen.TabIndex = 6;
            grpResumen.TabStop = false;
            grpResumen.Text = "Resumen";
            // 
            // lblPromedioGeneral
            // 
            lblPromedioGeneral.AutoSize = true;
            lblPromedioGeneral.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPromedioGeneral.Location = new Point(6, 40);
            lblPromedioGeneral.Name = "lblPromedioGeneral";
            lblPromedioGeneral.Size = new Size(135, 20);
            lblPromedioGeneral.TabIndex = 0;
            lblPromedioGeneral.Text = "Promedio general: ";
            // 
            // lblAprobadas
            // 
            lblAprobadas.AutoSize = true;
            lblAprobadas.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAprobadas.Location = new Point(6, 74);
            lblAprobadas.Name = "lblAprobadas";
            lblAprobadas.Size = new Size(85, 20);
            lblAprobadas.TabIndex = 1;
            lblAprobadas.Text = "Aprobadas:";
            // 
            // lblRecuperacion
            // 
            lblRecuperacion.AutoSize = true;
            lblRecuperacion.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblRecuperacion.Location = new Point(6, 108);
            lblRecuperacion.Name = "lblRecuperacion";
            lblRecuperacion.Size = new Size(118, 20);
            lblRecuperacion.TabIndex = 2;
            lblRecuperacion.Text = "En recuperacion:";
            lblRecuperacion.Click += lblRecuperacion_Click;
            // 
            // lblReprobadas
            // 
            lblReprobadas.AutoSize = true;
            lblReprobadas.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblReprobadas.Location = new Point(6, 143);
            lblReprobadas.Name = "lblReprobadas";
            lblReprobadas.Size = new Size(92, 20);
            lblReprobadas.TabIndex = 3;
            lblReprobadas.Text = "Reprobadas:";
            // 
            // lblSituacion
            // 
            lblSituacion.AutoSize = true;
            lblSituacion.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblSituacion.Location = new Point(6, 176);
            lblSituacion.Name = "lblSituacion";
            lblSituacion.Size = new Size(77, 20);
            lblSituacion.TabIndex = 4;
            lblSituacion.Text = "Situacion: ";
            // 
            // btnSalir
            // 
            btnSalir.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSalir.Location = new Point(643, 589);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(243, 52);
            btnSalir.TabIndex = 7;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(971, 682);
            Controls.Add(btnSalir);
            Controls.Add(grpResumen);
            Controls.Add(grpBoletin);
            Controls.Add(btnLimpiar);
            Controls.Add(btnResumen);
            Controls.Add(grpRegistroAsignatura);
            Controls.Add(grpEstudiante);
            Controls.Add(lblBoletinCalificaciones);
            Name = "Form1";
            Text = "Form1";
            grpEstudiante.ResumeLayout(false);
            grpEstudiante.PerformLayout();
            grpRegistroAsignatura.ResumeLayout(false);
            grpRegistroAsignatura.PerformLayout();
            grpBoletin.ResumeLayout(false);
            grpResumen.ResumeLayout(false);
            grpResumen.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblBoletinCalificaciones;
        private GroupBox grpEstudiante;
        private Label label1;
        private RadioButton rdbVespertina;
        private RadioButton rdbMatutina;
        private Label lblTanda;
        private TextBox txtEstudiante;
        private GroupBox grpRegistroAsignatura;
        private Label lblAsignatura;
        private Label lblP1;
        private Label lblCalificaciones;
        private ComboBox cmbAsignatura;
        private TextBox txtP3;
        private Label lblP3;
        private TextBox txtP2;
        private Label lblP2;
        private TextBox txtP1;
        private CheckBox chkAsistencia;
        private TextBox txtP4;
        private Label lblP4;
        private Button btnRegistrar;
        private Button btnResumen;
        private Button btnLimpiar;
        private GroupBox grpBoletin;
        private ListBox lstBoletin;
        private GroupBox grpResumen;
        private Label lblPromedioGeneral;
        private Label lblReprobadas;
        private Label lblRecuperacion;
        private Label lblAprobadas;
        private Label lblSituacion;
        private Button btnSalir;
    }
}
